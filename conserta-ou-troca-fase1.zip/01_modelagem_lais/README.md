# Fase 1 — Modelagem financeira e inteligência de dados

**Responsável:** Laís Eulálio  
**Versão do contrato:** 1.0 (documentação preparada a partir do Planejamento v1.3)  
**Natureza dos dados:** sintéticos, para finalidade educativa  
**Estado:** documentação pronta para revisão e inclusão na branch; os casos aprovados C01–C08 e a branch não foram acessados neste pacote.

## Objetivo

Definir um único contrato financeiro e qualitativo que possa ser reproduzido por planilha, MVP, Looker Studio, relatório e slides. O resultado compara custos anuais estimados; não é recomendação de compra.

## Regras de cálculo

- **Reparar:** custo líquido = custo do reparo + manutenção adicional − residual do aparelho reparado.
- **Custo anual de reparar:** custo líquido de reparar ÷ vida adicional estimada, em anos.
- **Trocar:** custo líquido = preço do substituto + acessórios − valor de venda do aparelho atual − residual futuro do substituto.
- **Custo anual de trocar:** custo líquido de trocar ÷ vida útil estimada do substituto, em anos.
- **Diferença anual:** custo anual de reparar − custo anual de trocar.
- Valores negativos na diferença favorecem financeiramente reparar; positivos favorecem trocar. Se o valor absoluto for **estritamente menor que R$ 0,01/ano**, há empate técnico.
- Custos líquidos negativos, entradas monetárias inválidas ou vida útil vazia/não numérica/menor ou igual a zero resultam em `n.a.` e não definem vencedor.
- Preserve precisão completa durante o cálculo; exiba moeda com duas casas decimais. Não arredonde os valores intermediários.
- O preço já pago pelo aparelho atual é custo passado e não entra na comparação.

## Casos e dados

Os oito casos sintéticos aprovados devem permanecer exatamente como registrados na fonte de dados da responsável. Este pacote **não replica nem preenche C01–C08**. O guia informa como testes de referência:

- **C01 — reprodução manual:** reparar: `420 + 80 − 120 = 380`; `380 ÷ 1,5 = 253,33 R$/ano`. Trocar: `1.800 + 90 − 180 − 450 = 1.260`; `1.260 ÷ 4 = 315,00 R$/ano`. A diferença não arredondada é negativa; reparar apresenta menor custo anual.
- **C03:** reparar R$ 370,00/ano; trocar R$ 282,86/ano; menor custo anual para trocar.

Esses valores de teste não substituem as entradas aprovadas na planilha e não devem ser usados para reconstruir dados ausentes.

## Critérios qualitativos

`risco_reparo`: `Baixo` | `Médio` | `Alto`  
`necessidade_usuario`: `Essencial` | `Importante` | `Adiável`  
`impacto_ambiental`: `Reparo favorece reuso` | `Equilibrado` | `Troca requer descarte responsável`

Os três critérios são registrados por caso, repetidos nas duas linhas do cenário de Looker e **não entram nas fórmulas**. A observação do caso deve explicar o aprendizado sem nomes, marcas reais, escola, turma ou opinião de participante.

## Limitações

Modelo didático simplificado. Não considera inflação, juros, financiamento, impostos, probabilidade estatística de falha, consumo de energia ou valor do dinheiro no tempo. Os dados são sintéticos e a conclusão financeira não substitui a análise de risco, necessidade de uso e impacto ambiental.

## Testes de referência

Execute, na pasta `01_modelagem_lais`, `python -m unittest -v test_modelo.py`. Os testes cobrem o exemplo explícito de C01, o limite estrito de empate, custo líquido negativo, entradas monetárias inválidas e vida útil inválida. A planilha canônica continua sendo a autoridade dos oito casos; os testes não criam uma base alternativa.

## Integrar ao repositório

1. Confirme com Caio que a branch de trabalho e as permissões estão corretas; não faça commit diretamente em `main`.
2. Copie a pasta `01_modelagem_lais` para a raiz do repositório local.
3. Confira os cabeçalhos e os oito casos contra a planilha aprovada, sem substituir nem redistribuir valores.
4. Na branch `lais/modelagem-dados`, revise os arquivos, rode `python -m unittest -v test_modelo.py` e verifique `git status`.
5. Configure localmente o nome e o e-mail `noreply` do GitHub, faça commit e push da branch, e compartilhe o hash com Caio e na tarefa correspondente do Notion. Caio integra em `main`.

Este pacote é material pronto para integração, **não é um commit publicado** e não comprova que os dados privados do Sheets/Looker foram conferidos.
